package com.dumb;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dumb.dao.DabaseOperation;

public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get all books and return dispatch to servlet
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection con;
		
		//prepare statement
		
		String title=request.getParameter("title");
		String authorName=request.getParameter("author");
		String pub=request.getParameter("publication");
		Double price=Double.parseDouble(request.getParameter("price"));
		
		String qry = "Insert into books(title,author,publication,price) values (?,?,?,?)";
		
		try {
			con = DabaseOperation.dbConnect();
			PreparedStatement preSta = con.prepareStatement(qry);
			preSta.setString(1, title);
			preSta.setString(2, authorName);
			preSta.setString(3, pub);
			preSta.setDouble(4, price);
			
			preSta.executeUpdate();
			response.sendRedirect("addBook.html");
			response.getWriter().println("Database succeess");
			
		}catch(SQLException f) {
			f.printStackTrace();
			response.getWriter().println("Database failed");
		}
		
			
	}

}

package com.dumb.model;

public class BookIssue{
	String bookTaken,section;
	int studentId;
	
	public String getBookTaken() {
		return bookTaken;
	}
	public void setBookTaken(String bookTaken) {
		this.bookTaken = bookTaken;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}

}